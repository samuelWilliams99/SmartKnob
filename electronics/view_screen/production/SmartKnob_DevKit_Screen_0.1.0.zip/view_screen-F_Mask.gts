G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.4*
G04 #@! TF.CreationDate,2025-10-14T18:37:16+01:00*
G04 #@! TF.ProjectId,view_screen,76696577-5f73-4637-9265-656e2e6b6963,0.1.0*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.4) date 2025-10-14 18:37:16*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,2.400000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,H1*
X94000000Y-100000000D03*
G04 #@! TD*
M02*
